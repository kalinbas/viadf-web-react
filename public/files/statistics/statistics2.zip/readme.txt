-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ViaDF Statistics Dataset
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

This archive contains the ViaDF Statistics Dataset from 01.06.2016 - 09.08.2017.

-------------
What's Inside
-------------

The complete statistics of searches done on ViaDF 2016 - 2017.

The data is provided in "tab-separated" text files, which each contain a header line.

    statistics.txt	Searches done on ViaDF
	
					FromLat: Latitude of origin of search 
					FromLng: Longitude of origin of search
					ToLat: Latitude of destination of search
					ToLng: Longitude of destination of search
					CreateDate: Date/Time when the search was done
					
					

    license.txt		License description

-------------------
Where It Comes From
-------------------

ViaDF produced this dataset using http://www.viadf.com.mx website.

We make it available to you under the Open Data Commons Attribution License (ODC-By) v1.0.
Please see the license summary and disclaimer below, and the full license text as given in license.txt.

-------------
About the project
-------------
ViaDF was done as a personal project by Bastian K�lin - kalinbas@gmail.com from 2010-2015. 
You can find more information about the project on

http://www.viadf.com.mx
https://www.facebook.com/viadf
https://www.twitter.com/viadf

---------------------------------
What You're Welcome to Do With It
---------------------------------

You are free:

    To Share: To copy, distribute and use the database.
    To Create: To produce works from the database.
    To Adapt: To modify, transform and build upon the database.

As long as you:

    Attribute: You must attribute any public use of the database, or works
    produced from the database, in the manner specified in the ODC-By. For any
    use or redistribution of the database, or works produced from it, you must
    make clear to others the license of the database and keep intact any
    notices on the original database.

Disclaimer:

    The above summary is not the license text. It is simply a handy reference
    for understanding the ODC-By 1.0 � it is a human-readable expression of some
    of its key terms. This summary has no legal value, and its contents do not
    appear in the actual license. Read the full ODC-By 1.0 license text for the
    exact terms that apply.

THIS DATABASE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL SIMPLEGEO, INC. BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS DATABASE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The full text of the license is given in the LICENSE.txt file. It can also be found at 
http://opendatacommons.org/licenses/by/1.0/