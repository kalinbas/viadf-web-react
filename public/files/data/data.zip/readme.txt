-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  ViaDF Route Dataset
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

This archive contains the ViaDF Route Dataset from 08.07.2015.

-------------
What's Inside
-------------

The complete route dataset that is used to calculate routes for public transport in Mexico City by ViaDF.

The data is provided in "tab-separated" text files, which each contain a header line.

    types.txt 		Types of transports used (Examples: Metro, Metrobus, Microbus, etc...) with corresponding metadata
	
					ID: Id of type of transport
					Name: Name of type of transport
					AverageSpeed: Estimated average speed of this type of transport in km/h


    routes.txt  	Routes of transport (Example: Metro Line X) with corresponding metadata
	
					ID: Id of route
					Name: Name of route
					Status: 0 - not yet verified, not used in ViaDF Search / 2 - verified and added to ViaDF search index
					SplitRoutePieceID: 	If it is set, the route is one-way. If it is empty, the route is two-way.
										One-Way example: FromName----------ToName(SplitRoutePieceID) -----------------FromName	
										Two-Way example: FromName----------ToName	
					FromName: Starting point of route (this corresponds to the routepiece with lowest ID)
					ToName: Ending point of route (this corresponds to the routepiece with highest ID (two-way) - or routepiece with ID = SplitRoutePieceID (one-way))
					TypeID: Id of type of transport to which this route belongs

    routepieces.txt	The stops / points of a route of transport (Example: Metro Station X). They are ordered by ID ascending.
	
					ID: Id of routepiece
					Name: Name of routepiece (if its a named station - otherwise empty)
					Lat: Latitude of position
					Lng: Longitude of position
					RouteID: Id of route to which this routepiece belongs



    license.txt		License description

-------------------
Where It Comes From
-------------------

ViaDF produced this dataset using crowdsourcing on the http://www.viadf.com.mx website.

We make it available to you under the Open Data Commons Attribution License (ODC-By) v1.0.
Please see the license summary and disclaimer below, and the full license text as given in license.txt.

-------------------
About the project
-------------------
ViaDF was done as a personal project by Bastian K�lin - kalinbas@gmail.com from 2010-2015. 
You can find more information about the project on

http://www.viadf.com.mx
https://www.facebook.com/viadf
https://www.twitter.com/viadf

---------------------------------
What You're Welcome to Do With It
---------------------------------

You are free:

    To Share: To copy, distribute and use the database.
    To Create: To produce works from the database.
    To Adapt: To modify, transform and build upon the database.

As long as you:

    Attribute: You must attribute any public use of the database, or works
    produced from the database, in the manner specified in the ODC-By. For any
    use or redistribution of the database, or works produced from it, you must
    make clear to others the license of the database and keep intact any
    notices on the original database.

Disclaimer:

    The above summary is not the license text. It is simply a handy reference
    for understanding the ODC-By 1.0 � it is a human-readable expression of some
    of its key terms. This summary has no legal value, and its contents do not
    appear in the actual license. Read the full ODC-By 1.0 license text for the
    exact terms that apply.

THIS DATABASE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL SIMPLEGEO, INC. BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS DATABASE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The full text of the license is given in the LICENSE.txt file. It can also be found at 
http://opendatacommons.org/licenses/by/1.0/